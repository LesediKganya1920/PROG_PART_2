package part1;

import javax.swing.*;
import java.awt.*;
import java.util.regex.Pattern;

public class RegisterForm extends JFrame {
    private JTextField firstNameField, lastNameField, usernameField, phoneField;
    private JPasswordField passwordField;
    private JButton registerButton, backButton;

    public RegisterForm() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("QuickChat - Register");
        setSize(450, 470);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK);
        JLabel headerLabel = new JLabel("Create New Account");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 32, 20, 32));
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 7, 7, 7);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.33;
        formPanel.add(new JLabel("First Name:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.67;
        firstNameField = new JTextField(18);
        formPanel.add(firstNameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.33;
        formPanel.add(new JLabel("Last Name:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.67;
        lastNameField = new JTextField(18);
        formPanel.add(lastNameField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0.33;
        JLabel usernameLabel = new JLabel("<html>Username:<br/><small>(max 5 chars, must have _)</small></html>");
        formPanel.add(usernameLabel, gbc);
        gbc.gridx = 1; gbc.weightx = 0.67;
        usernameField = new JTextField(18);
        formPanel.add(usernameField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0.33;
        JLabel passwordLabel = new JLabel("<html>Password:<br/><small>(8+ chars, capital, number, special)</small></html>");
        formPanel.add(passwordLabel, gbc);
        gbc.gridx = 1; gbc.weightx = 0.67;
        passwordField = new JPasswordField(18);
        formPanel.add(passwordField, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.weightx = 0.33;
        JLabel phoneLabel = new JLabel("<html>Phone:<br/><small>(+27 followed by 9 digits)</small></html>");
        formPanel.add(phoneLabel, gbc);
        gbc.gridx = 1; gbc.weightx = 0.67;
        phoneField = new JTextField(18);
        formPanel.add(phoneField, gbc);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(Color.WHITE);
        registerButton = new JButton("Register");
        registerButton.setBackground(Color.BLACK);
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        registerButton.addActionListener(e -> handleRegistration());

        backButton = new JButton("Back");
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        backButton.addActionListener(e -> {
            dispose();
            new MainForm().setVisible(true);
        });

        buttonPanel.add(registerButton);
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void handleRegistration() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String phone = phoneField.getText().trim();

        if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (username.length() > 5) {
            JOptionPane.showMessageDialog(this, "Username must be 5 characters or less!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!username.contains("_")) {
            JOptionPane.showMessageDialog(this, "Username must contain an underscore (_)!","Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (password.length() < 8) {
            JOptionPane.showMessageDialog(this, "Password must be at least 8 characters!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!Pattern.compile("[A-Z]").matcher(password).find()) {
            JOptionPane.showMessageDialog(this, "Password must contain at least one capital letter!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!Pattern.compile("[0-9]").matcher(password).find()) {
            JOptionPane.showMessageDialog(this, "Password must contain at least one number!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!Pattern.compile("[!@#$%^&*(),.?\":{}|<>]").matcher(password).find()) {
            JOptionPane.showMessageDialog(this, "Password must contain at least one special character!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!phone.matches("\\+27\\d{9}")) {
            JOptionPane.showMessageDialog(this,"Phone must be: +27 followed by 9 digits!\nExample: +27812345678","Validation Error",JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (LoginService.registerUser(firstName, lastName, username, password, phone)) {
            JOptionPane.showMessageDialog(this, "Registration successful!\nYou can now login.", "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
            new LoginForm().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Username already exists!", "Registration Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegisterForm().setVisible(true));
    }
}