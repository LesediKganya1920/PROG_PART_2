package part1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class LoginService {
    private static final String FILENAME = "users.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public static class UserData {
        private String firstName, lastName, username, password, phone;
        
        public UserData(String firstName, String lastName, String username, String password, String phone) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.phone = phone;
        }
        
        public String getFirstName() { return firstName; }
        public String getLastName() { return lastName; }
        public String getUsername() { return username; }
        public String getPassword() { return password; }
        public String getPhone() { return phone; }
    }

    public static boolean registerUser(String firstName, String lastName, String username, String password, String phone) {
        List<UserData> users = loadUsers();
        for (UserData user : users) {
            if (user.getUsername().equals(username)) return false;
        }
        users.add(new UserData(firstName, lastName, username, password, phone));
        saveUsers(users);
        return true;
    }

    public static boolean verifyLogin(String username, String password) {
        List<UserData> users = loadUsers();
        for (UserData user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) return true;
        }
        return false;
    }

    public static String getUserFullName(String username) {
        List<UserData> users = loadUsers();
        for (UserData user : users) {
            if (user.getUsername().equals(username)) return user.getFirstName() + " " + user.getLastName();
        }
        return username;
    }

    public static List<String> getUserNames() {
        List<UserData> users = loadUsers();
        List<String> usernames = new ArrayList<>();
        for (UserData user : users) {
            usernames.add(user.getUsername());
        }
        return usernames;
    }

    private static List<UserData> loadUsers() {
        File file = new File(FILENAME);
        if (!file.exists()) return new ArrayList<>();
        try (FileReader reader = new FileReader(file)) {
            Type listType = new TypeToken<ArrayList<UserData>>(){}.getType();
            List<UserData> users = gson.fromJson(reader, listType);
            return users != null ? users : new ArrayList<>();
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    private static void saveUsers(List<UserData> users) {
        try (FileWriter writer = new FileWriter(FILENAME)) {
            gson.toJson(users, writer);
        } catch (IOException e) {
            // Handle error
        }
    }
}