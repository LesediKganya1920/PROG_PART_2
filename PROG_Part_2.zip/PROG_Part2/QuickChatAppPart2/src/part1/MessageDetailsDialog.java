package part1;

import javax.swing.*;
import java.awt.*;

public class MessageDetailsDialog extends JDialog {
    private final Message message;
    private final String action;

    public MessageDetailsDialog(Window parent, Message message, String action) {
        super(parent, "Message Details", Dialog.ModalityType.APPLICATION_MODAL);
        this.message = message;
        this.action = action;
        initComponents();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setSize(420, 400);
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK);
        JLabel headerLabel = new JLabel("Message " + action.toUpperCase() + " Successfully!");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        JPanel detailsPanel = new JPanel(new GridBagLayout());
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        detailsPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addLabelDetails(detailsPanel, gbc, "Message ID:", message.generateId(), 0);
        addLabelDetails(detailsPanel, gbc, "Message Number:", "1", 1);
        addLabelDetails(detailsPanel, gbc, "Message Hash:", message.generateHash(1), 2);
        addLabelDetails(detailsPanel, gbc, "Sender:", message.getSender(), 3);
        addLabelDetails(detailsPanel, gbc, "Recipient:", message.getPhone(), 4);
        addLabelDetails(detailsPanel, gbc, "Timestamp:", java.time.LocalDateTime.now().toString(), 5);

        gbc.gridx = 0; gbc.gridy = 6; gbc.weightx = 0.3;
        JLabel contentLabel = new JLabel("Content:");
        contentLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        detailsPanel.add(contentLabel, gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        JTextArea contentValue = new JTextArea(message.getText());
        contentValue.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        contentValue.setLineWrap(true);
        contentValue.setWrapStyleWord(true);
        contentValue.setEditable(false);
        detailsPanel.add(contentValue, gbc);

        add(detailsPanel, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.setBackground(Color.BLACK);
        closeButton.setForeground(Color.WHITE);
        closeButton.addActionListener(e -> dispose());
        JPanel closePanel = new JPanel();
        closePanel.add(closeButton);
        add(closePanel, BorderLayout.SOUTH);
    }

    private void addLabelDetails(JPanel panel, GridBagConstraints gbc, String label, String value, int row) {
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0.3;
        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        panel.add(l, gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        JLabel v = new JLabel(value);
        v.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panel.add(v, gbc);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Message testMsg = new Message("John Doe", "+27823456789012", "Test message", "Send");
            JFrame dummyParent = new JFrame();
            dummyParent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            dummyParent.setVisible(true);
            new MessageDetailsDialog(dummyParent, testMsg, "sent").setVisible(true);
        });
    }
}