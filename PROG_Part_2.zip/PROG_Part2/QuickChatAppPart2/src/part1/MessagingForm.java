package part1;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MessagingForm extends JFrame {
    private final String loggedInUser;
    private JTextArea displayArea;
    private JButton sendButton, viewButton, quitButton;

    public MessagingForm(String username) {
        this.loggedInUser = username;
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("QuickChat - Messaging Menu");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK);
        JLabel headerLabel = new JLabel("Welcome, " + loggedInUser + "!");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        displayArea.setMargin(new Insets(10, 10, 10, 10));
        displayArea.setBackground(Color.WHITE);
        displayArea.setForeground(Color.BLACK);
        displayArea.setText("QUICKCHAT MESSAGING SYSTEM\nSelect an option from the menu below:\n1. Send Messages\n2. View Messages\n3. Quit\n");
        JScrollPane scrollPane = new JScrollPane(displayArea);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 10, 0));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        buttonPanel.setBackground(Color.WHITE);

        sendButton = new JButton("1. Send Messages");
        sendButton.setBackground(Color.BLACK);
        sendButton.setForeground(Color.WHITE);
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        sendButton.setFocusPainted(false);
        sendButton.addActionListener(e -> openSendMessageForm());

        viewButton = new JButton("2. View Messages");
        viewButton.setBackground(Color.BLACK);
        viewButton.setForeground(Color.WHITE);
        viewButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        viewButton.setFocusPainted(false);
        viewButton.addActionListener(e -> viewMessages());

        quitButton = new JButton("3. Quit");
        quitButton.setBackground(Color.BLACK);
        quitButton.setForeground(Color.WHITE);
        quitButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        quitButton.setFocusPainted(false);
        quitButton.addActionListener(e -> quitApplication());

        buttonPanel.add(sendButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(quitButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void openSendMessageForm() {
        String input = JOptionPane.showInputDialog(this, "How many messages would you like to send?", "Message Quantity", JOptionPane.QUESTION_MESSAGE);
        if (input != null && !input.trim().isEmpty()) {
            try {
                int quantity = Integer.parseInt(input.trim());
                if (quantity > 0) {
                    new SendMessageForm(this, loggedInUser, quantity).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Please enter a positive number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void viewMessages() {
        List<Message> messages = MessageStorage.loadMessages();
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No messages found.", "View Messages", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("STORED MESSAGES\n");
        int counter = 1;
        for (Message msg : messages) {
            sb.append("Message ").append(counter).append(" | ID: ").append(msg.generateId())
                .append(" | Hash: ").append(msg.generateHash(counter)).append("\nFrom: ").append(msg.getSender())
                .append(" | To: ").append(msg.getPhone()).append("\nContent: ").append(msg.getText())
                .append("\nTime: ").append(java.time.LocalDateTime.now().toString()).append("\n\n");
            counter++;
        }
        displayArea.setText(sb.toString());
    }

    private void quitApplication() {
        int total = MessageStorage.loadMessages().size();
        JOptionPane.showMessageDialog(this, "Total messages sent: " + total + "\nThank you for using QuickChat!", "Goodbye", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MessagingForm("TestUser").setVisible(true));
    }
}