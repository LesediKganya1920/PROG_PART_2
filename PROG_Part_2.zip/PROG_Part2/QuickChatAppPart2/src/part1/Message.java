package part1;

public class Message {
    private String sender;
    private String phone;
    private String text;
    private String action;

    // Default constructor for Gson
    public Message() {
    }

    // Constructor matching how it's called in SendMessageForm
    public Message(String sender, String phone, String text) {
        this.sender = sender;
        this.phone = phone;
        this.text = text;
        this.action = "Send"; // Default action
    }

    // Overloaded constructor with action parameter
    public Message(String sender, String phone, String text, String action) {
        this.sender = sender;
        this.phone = phone;
        this.text = text;
        this.action = action;
    }

    // Getters
    public String getSender() { return sender; }
    public String getPhone() { return phone; }
    public String getText() { return text; }
    public String getAction() { return action; }
    
    // Setters for Gson
    public void setSender(String sender) { this.sender = sender; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setText(String text) { this.text = text; }
    public void setAction(String action) { this.action = action; }

    public String validateLength() {
        if (text == null || text.length() > 250) {
            return "Message exceeds 250 character limit.";
        }
        return "Message ready to send.";
    }

    public String validatePhone() {
        // International format: starts with '+', followed by digits, length 11-15
        if (phone != null && phone.matches("^\\+\\d{11,15}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Invalid international phone format.";
    }

    public String generateHash(int messageNum) {
        if (text == null || text.isEmpty()) {
            return ":"+messageNum+":";
        }
        String[] words = text.split("\\s+");
        String firstWord = words.length > 0 ? words[0].replaceAll("[^a-zA-Z]", "") : "";
        String lastWord = words.length > 0 ? words[words.length - 1].replaceAll("[^a-zA-Z]", "") : "";
        return firstWord + ":" + messageNum + ":" + lastWord;
    }

    public String generateId() {
        // Simple unique 10-digit ID
        String combined = (sender != null ? sender : "") + 
                         (phone != null ? phone : "") + 
                         (text != null ? text : "") + 
                         (action != null ? action : "");
        String id = String.valueOf(Math.abs(combined.hashCode()));
        return id.length() >= 10 ? id.substring(0, 10) : String.format("%010d", Long.parseLong(id));
    }

    public String performAction() {
        if (action == null) {
            return "Unknown action.";
        }
        if ("Send".equalsIgnoreCase(action)) {
            return "Message successfully sent.";
        } else if ("Discard".equalsIgnoreCase(action)) {
            return "Press 0 to delete message.";
        } else if ("Store".equalsIgnoreCase(action)) {
            return "Message successfully stored.";
        } else {
            return "Unknown action.";
        }
    }
}