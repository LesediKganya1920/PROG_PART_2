package part1;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import java.io.File;
import java.util.List;

public class MessageStorageTest {
    private static final String TEST_FILENAME = "messages.json";
    
    @Before
    public void setUp() {
        deleteTestFile();
    }
    
    @After
    public void tearDown() {
        deleteTestFile();
    }
    
    private void deleteTestFile() {
        File file = new File(TEST_FILENAME);
        if (file.exists()) {
            file.delete();
        }
    }
    
    @Test
    public void testSaveMessage_SingleMessage() {
        Message msg = new Message("John Doe", "+27123456789012", "Test message", "Send");
        MessageStorage.saveMessage(msg);
        List<Message> messages = MessageStorage.loadMessages();
        assertEquals(1, messages.size());
    }
    
    @Test
    public void testSaveMessage_MultipleMessages() {
        Message msg1 = new Message("John", "+27123456789012", "Message 1", "Send");
        Message msg2 = new Message("Jane", "+27987654321098", "Message 2", "Store");
        Message msg3 = new Message("Bob", "+27555555555555", "Message 3", "Send");
        
        MessageStorage.saveMessage(msg1);
        MessageStorage.saveMessage(msg2);
        MessageStorage.saveMessage(msg3);
        
        List<Message> messages = MessageStorage.loadMessages();
        assertEquals(3, messages.size());
    }
    
    @Test
    public void testLoadMessages_EmptyFile() {
        List<Message> messages = MessageStorage.loadMessages();
        assertNotNull(messages);
        assertEquals(0, messages.size());
    }
    
    @Test
    public void testLoadMessages_AfterSave() {
        Message msg = new Message("Sender", "+27123456789012", "Hello World", "Send");
        MessageStorage.saveMessage(msg);
        
        List<Message> messages = MessageStorage.loadMessages();
        assertNotNull(messages);
        assertEquals(1, messages.size());
    }
    
    @Test
    public void testSaveMessage_DataIntegrity() {
        Message originalMsg = new Message("Alice", "+27111111111111", "Test content", "Store");
        MessageStorage.saveMessage(originalMsg);
        
        List<Message> messages = MessageStorage.loadMessages();
        Message loadedMsg = messages.get(0);
        
        assertEquals(originalMsg.getSender(), loadedMsg.getSender());
        assertEquals(originalMsg.getPhone(), loadedMsg.getPhone());
        assertEquals(originalMsg.getText(), loadedMsg.getText());
    }
    
    @Test
    public void testLoadMessages_ReturnsNewList() {
        List<Message> list1 = MessageStorage.loadMessages();
        List<Message> list2 = MessageStorage.loadMessages();
        assertNotSame(list1, list2);
    }
    
    @Test
    public void testSaveMessage_Persistence() {
        Message msg1 = new Message("User1", "+27123456789012", "First", "Send");
        MessageStorage.saveMessage(msg1);
        
        Message msg2 = new Message("User2", "+27987654321098", "Second", "Store");
        MessageStorage.saveMessage(msg2);
        
        List<Message> messages = MessageStorage.loadMessages();
        assertEquals(2, messages.size());
    }
    
    @Test
    public void testLoadMessages_FileCreated() {
        Message msg = new Message("Test", "+27123456789012", "Content", "Send");
        MessageStorage.saveMessage(msg);
        
        File file = new File(TEST_FILENAME);
        assertTrue(file.exists());
    }
    
    @Test
    public void testSaveMessage_OrderPreserved() {
        Message msg1 = new Message("First", "+27111111111111", "First message", "Send");
        Message msg2 = new Message("Second", "+27222222222222", "Second message", "Send");
        Message msg3 = new Message("Third", "+27333333333333", "Third message", "Send");
        
        MessageStorage.saveMessage(msg1);
        MessageStorage.saveMessage(msg2);
        MessageStorage.saveMessage(msg3);
        
        List<Message> messages = MessageStorage.loadMessages();
        assertEquals("First", messages.get(0).getSender());
        assertEquals("Second", messages.get(1).getSender());
        assertEquals("Third", messages.get(2).getSender());
    }
    
    @Test
    public void testLoadMessages_EmptyList() {
        List<Message> messages = MessageStorage.loadMessages();
        assertTrue(messages.isEmpty());
    }
}